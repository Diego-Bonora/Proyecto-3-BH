 <?php
    $server = 'localhost';
    $username = 'root';
    $pasword = 'proyecto2021';
    $database = 'NetClip';

    try {
        $conn = new PDO("mysql:host=$server;dbname=$database;", $username, $pasword);
    } catch (PDOException $e) {
        die('conected failed: ' . $e->getMessage());
    }

    ?>