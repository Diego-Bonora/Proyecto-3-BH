<?php
session_start();
$connect = mysqli_connect("localhost", "root", "proyecto2021", "NetClip");
require 'assets/scripts/database.php';

if (isset($_SESSION['user_id'])) {
$records = $conn->prepare('SELECT ID_usuarios, Email, Password, Nombre, Apellido FROM usuarios WHERE ID_usuarios = :ID_usuarios');
$records->bindParam(':ID_usuarios', $_SESSION['user_id']);
$records->execute();
$results = $records->fetch(PDO::FETCH_ASSOC);

$user = null;

if (count($results) > 0) {
$user = $results;
}
}

?>


<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8" />
    <meta http - equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/style/style.css?v=<?php echo time(); ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/68768a5d73.js" crossorigin="anonymous"></script>
    <title>Suizo</title>

    <script>
        $(document).ready(function() {

            $("#hover-cont").mouseover(function() {
                $("#busca-input").removeClass("busca-noshow").addClass("busca-show");
            });

            $("#hover-cont").mouseout(function() {
                $("#busca-input").removeClass("busca-show").addClass("busca-noshow");
            });

            $("#hover-cont").focusin(function() {
                $("#busca-input").removeClass("busca-noshow").addClass("busca-show");
            });

            $("#hover-cont").focusout(function() {
                $("#busca-input").removeClass("busca-show").addClass("busca-noshow");
            });

        });
    </script>
</head>

<body>
    <?php require './assets/scripts/header.php'; ?>
    <script src="./assets/scripts/main.js"></script>

    <body>
        <section>
            <div class="bases   ">

                <br />
                <br />
                <h1>
                    <strong>BASES Y CONDICIONES PROGRAMA DE BENEFICIOS Points DE SUIZO.</strong>
                </h1>
                <br />
                <br />
                <h2>PROGRAMA DE FIDELIDAD</h2>
                <br />
                <hr />
                <br />
                <br />
                <h3>1. OBJETO DEL PROGRAMA</h3>
                <br />
                <p class="num-p">1.1.</p>
                <p>
                    Con el propósito de beneficiar y premiar a nuestros clientes Suizo, ha
                    creado un servicio de puntos “Points”.
                </p>
                <p class="num-p">1.2.</p>
                <p>
                    Mediante la participación en el programa Points, en adelante el
                    “Programa” los clientes podrán obtener a partir de la adquisición de
                    productos de la Empresa, “Puntos Canjeables” por cualquier producto de
                    la Empresa.
                </p>
                <p class="num-p">1.3.</p>
                <p>
                    Los Puntos Canjeables obtenidos son para uso personal y no son
                    transferibles.
                </p>
                <br />
                <hr />
                <br />
                <br />

                <h3>2. USUARIOS</h3>
                <p class="num-p">2.1.</p>
                <p>
                    Puede formar parte del programa “Points” toda persona física, mayor de
                    18 años, capaz, que haya aceptado las presentes bases y condiciones, en
                    adelante “Bases y Condiciones”, en adelante el “Usuario”.
                </p>
                <p class="num-p">2.2.</p>
                <p>
                    El Usuario será responsable de los daños y perjuicios que fueran
                    consecuencia de actos u omisiones propios del Usuario.
                </p>
                <br />
                <hr />
                <br />
                <br />
                <h3>3. PROGRAMA Points</h3>
                <br />
                <p class="num-p">3.1.</p>
                <p>
                    Points es un programa por el cual los Usuarios podrán adquirir Puntos
                    Canjeables mediante sus compras--en efectivo, tarjetas de débito,
                    tarjetas de crédito, ticket alimentación electrónico y tarjeta Uruguay
                    Social--en cualquier unidad de negocio de la Empresa, y canjearlos por
                    cualquier producto disponible en las unidades de negocio de la Empresa.
                </p>
                <p class="num-p">3.2.</p>
                <p>
                    El Usuario será responsable frente a la Empresa y cualquier tercero por
                    el uso inadecuado del Programa desde su Usuario.
                </p>
                <p class="num-p">3.3.</p>
                <p>
                    La Empresa se reserva el derecho de dar de baja o inhabilitar al Usuario
                    del Programa cuando, a solo criterio de la Empresa, considere que se
                    hace o ha hecho uso indebido o inconveniente del mismo, perdiendo la
                    totalidad de los Puntos Canjeables obtenidos hasta el momento.
                </p>
                <p class="num-p">3.4.</p>
                <p>
                    El puntaje generado en un Usuario no será transferible a otros Usuarios
                    bajo ningún título o causa (ej.: disolución de sociedad conyugal,
                    fallecimiento, incapacidad, etc.) salvo en aquellas situaciones que a
                    sola voluntad de la Empresa puedan ser consideradas como una excepción.
                </p>
                <br />
                <hr />
                <br />
                <br />
                <h3>4. ÁMBITO DE APLICACIÓN</h3>
                <br />
                <br />
                <p class="num-p">4.1.</p>
                <p>
                    Los Usuarios podrán obtener Puntos Canjeable que se acreditarán a su
                    Usuario Points en oportunidad de la adquisición de cualquier producto en
                    cualquier unidad de negocio de la Empresa, siempre que dicha adquisición
                    se abone mediante el pago con efectivo, tarjetas de débito, tarjetas de
                    crédito, ticket alimentación electrónico y tarjeta Uruguay Social. Las
                    adquisiciones que sean abonadas totalmente mediante otras formas de
                    pago, diferentes a las antes mencionadas, no acumularán Puntos
                    Canjeables. En caso de adquisiciones que sean abonadas parcialmente
                    mediante otras formas de pago, acumularán puntos solo por el monto pago
                    en efectivo, tarjetas de débito, tarjetas de crédito, ticket
                    alimentación electrónico y tarjeta Uruguay Social.
                </p>
                <p class="num-p">4.2.</p>
                <p>
                    Los Puntos Canjeables son adjudicados en función del precio de la
                    adquisición efectuada, a razón de un 10% por cada compras efectuada.
                    Toda adquisición por monto inferior al indicado no generará Puntos
                    Canjeables, no generando tampoco Puntos Canjeables la fracción
                    resultante inferior a la suma indicada. Toda devolución de mercadería
                    implicará la deducción de los Puntos Canjeables generados en dicha
                    compra.
                </p>
                <p>
                    4.3. En cada operación de compra que el Usuario realice en la Empresa se
                    le informará, conjuntamente con el ticket de compra, la cantidad de
                    Puntos Canjeables generados, así como el saldo acreditado.
                </p>
                <hr />
                <br />
                <h3>5. PUNTOS SOLIDARIOS.</h3>
                <br />
                <p class="num-p">5.1.</p>
                <p>
                    Conjuntamente con la posibilidad de acumulación de Puntos Canjeables
                    para uso personal del Usuario PLUS, por cada 10 (diez) Puntos Canjeables
                    acumulados por cada Usuario, la Empresa adicionará 1 (un) punto a ser
                    adjudicado a una/unas institución/es con fines solidarios designada por
                    la Empresa que será informado en el sitio web de la empresa www.plus.uy.
                    La adjudicación de los Puntos con fines solidarios adicionados por la
                    empresa tendrá como tope máximo 4.000.000 por semestre, entendiéndose
                    por semestre a los períodos entre el 1 de enero a 30 de junio, y 1 de
                    julio a 31 de diciembre.
                </p>
                <br />
                <hr />
                <br />
                <br />
                <h3>6. PRODUCTOS CANJEABLES.</h3>
                <br />
                <p class="num-p">6.1.</p>
                <p>
                    Los Puntos Canjeables obtenidos por cada Usuario podrán ser canjeados
                    por cualquier producto que se encuentre a la venta en cualquier unidad
                    de negocio de la Empresa.
                </p>
                <p class="num-p">6.2.</p>
                <p>Para poder realizar un canje, el Usuario deberá tener:</p>
                <p>
                    a) como mínimo 51 Puntos Canjeables acumulados en el saldo disponible y;
                </p>
                <p>
                    b) completos los datos del Usuario que el Programa “PLUS” a dicho
                    momento requiera.
                </p>
                <p class="num-p">6.3.</p>
                <p>
                    Solicitado el canje por parte del Usuario PLUS, deberá presentar su C.I.
                    y efectuado el mismo, se debitara del saldo disponible del Usuario PLUS
                    el equivalente al precio del producto adquirido. Solamente el titular
                    del Usuario PLUS podrá solicitar canje, y siempre presentando su C.I.
                    vigente y en buenas condiciones.
                </p>
                <br />
                <hr />
                <br />
                <br />
                <h3>7. COMUNICACIONES Y CONSULTAS</h3>
                <br />
                <p class="num-p">7.1.</p>
                <p>
                    El Usuario PLUS puede resolver cualquier consulta que tenga, o cualquier
                    comunicación que debiera efectuar con relación al Programa, a través del
                    sitio web www.plus.uy o mediante el siguiente número telefónico
                    08008065.
                </p>
                <br />
                <hr />
                <br />
                <br />
                <h3>8. USUARIOS PLUS SIN ACTIVIDAD. VENCIMIENTO DE PUNTOS GENERADOS.</h3>
                <br />
                <p class="num-p">8.1.</p>
                <p>
                    Se considera Usuario PLUS sin actividad todo aquel que no registre
                    actividad dentro del Programa—ya fuere por adquisición de productos o
                    canje de puntos—por un período de tres (3) meses corridos a contar del
                    último movimiento.
                </p>
                <p class="num-p">8.2.</p>
                <p>
                    Verificado el transcurso del lapso indicado en el apartado anterior,
                    caducarán los Puntos Canjeables obtenidos de pleno derecho, y el saldo
                    del Usuario PLUS será de cero (0).
                </p>
                <br />
                <hr />
                <br />
                <br />
                <h3>9. MODIFICACION DE LAS CONDICIONES GENERALES DE USO.</h3>
                <br />
                <p class="num-p">9.1.</p>
                <p>
                    La Empresa se reserva el derecho de modificar total o parcialmente las
                    presentes bases y condiciones en cualquier momento. Las modificaciones a
                    las Bases y Condiciones se notificarán al ingresar a la página web
                    www.plus.uy mediante una ventana en modo Pop-up y/o a través de
                    cualquier otra forma que la Empresa pueda determinar, y los Usuarios
                    tendrán un plazo de 30 días para aceptarlas o darse de baja del
                    programa, en caso de no pronunciarse, al pasar los 30 días se tomarán
                    por aceptadas.
                </p>
                <p class="num-p">9.2.</p>
                <p>
                    Las modificaciones que la Empresa realice tendrán efecto a partir de los
                    30 días de notificado el cambio de las mismas. Se aplicarán a todos los
                    Usuarios PLUS activos a la fecha de la modificación y las personas que
                    posterior a dicha modificación sean Usuarios PLUS.
                </p>
                <p class="num-p">9.3.</p>
                <p>
                    La modificación de las presentes Bases y Condiciones será publicada en
                    el sitio www.plus.uy dentro del Programa PLUS.
                </p>
                <p class="num-p">9.4.</p>
                <p>
                    La Empresa no será responsable, en ningún caso, por las modificaciones
                    totales o parciales de las Bases y Condiciones del presente Programa.
                </p>
                <br />
                <hr />
                <br />
                <br />
                <h3>10. FINALIZACIÓN</h3>
                <br />
                <p class="num-p">10.1.</p>
                <p>
                    La Empresa se reserva el derecho de finalizar el Programa en cualquier
                    momento mediante previo aviso de un mes a los Usuarios PLUS en la web
                    www.plus.uy
                </p>
                <br />
                <hr />
                <br />
                <br />
                <h3>11. RESPONSABILIDADES</h3>
                <br />
                <p class="num-p">11.1.</p>
                <p>
                    La Empresa no se hace responsable de la utilización deficiente ni
                    fraudulenta por parte de los Usuarios PLUS ni de terceros del presente
                    Programa.
                </p>
                <p class="num-p">11.2.</p>
                <p>
                    El Usuario será responsable de los daños y perjuicios que fueran
                    consecuencia de actos u omisiones propios del Usuario.
                </p>
                <br />
                <hr />
                <br />
                <br />
                <h3>12. LEGISLACIÓ</h3>
                <br />
                <p class="num-p">12.1.</p>
                <p>
                    Las Bases y Condiciones del Programa se regirán, interpretarán,
                    cumplirán y ejecutarán conforme a las leyes y normas de la República
                    Oriental del Uruguaya, en todo lo que expresamente no se haya modificado
                    en la presente, conforme a la autonomía de la voluntad de los
                    contratantes.
                </p>
                <br />
                <hr />
                <br />
                <br />
                <h3>13. CONSIDERACIONES FINALES.</h3>
                <br />
                <p class="num-p">13.1.</p>
                <p>
                    La eventual nulidad de alguna de las cláusulas del presente no importará
                    la nulidad de las restantes.
                </p>
                <p class="num-p">13.2.</p>
                <p>
                    El hecho que la Empresa omita exigir el cumplimiento de un término o
                    condición en particular del Programa o más de uno de ellos, no
                    constituye una renuncia a dicho término o condición para la Empresa.
                </p>
                <p class="num-p">13.3.</p>
                <p>
                    La participación en el Programa PLUS implica la aceptación de todas las
                    condiciones establecidas en el presente, las que se consideran conocidas
                    por todos los Usuarios desde su Adhesión al Programa.
                </p>
                <p class="num-p">13.4.</p>
                <p>
                    La Empresa se reserva el derecho de modificar las presentes Bases y
                    Condiciones sin previo aviso.
                </p>
                <br />
                <hr />
                <br />
                <br />
                <h3>14. ACTUALIZACIÓN DE DATOS DEL USUARIO</h3>
                <br />
                <p class="num-p">14.1.</p>
                <p>
                    El Usuario deberá comunicar en forma inmediata y fehaciente--mediante
                    las vías aceptadas en las Bases y Condiciones--a la Empresa, de
                    cualquier cambio que se produzca en sus datos personales. Si así no lo
                    hiciese será causal suficiente para poder ser dado de baja del Programa
                    PLUS.
                </p>
                <p class="num-p">14.2.</p>
                <p>
                    Cualquier comunicación cursada por la Empresa a un Usuario se
                    considerará notificada si fuere remitida al domicilio y/o
                    telefónicamente y/o a través de correo electrónico a su dirección de
                    correo obrante en los registros de la Empresa.
                </p>
                <p class="num-p">14.3.</p>
                <p>
                    La Empresa no será responsable, en ningún caso, de reclamos que tuviere
                    como fundamento la falta de información del Usuario o el manejo por
                    parte del Usuario de fuentes de información desactualizadas.
                </p>
                <br />
                <hr />
                <br />
                <br />
                <h3>15. RENUNCIA</h3>
                <br />
                <p class="num-p">15.1.</p>
                <p>
                    El Usuario podrá poner fin a su participación en el Programa en
                    cualquier momento completando la solicitud de baja del servicio, en
                    atencion al cliente. Una vez el Usuario sea dado de baja no podrá disponer del saldo
                    de Puntos Canjeables que tuviere acumulado, quedando este en 0 (cero).
                </p>
                <br />
                <hr />
                <br />
                <br />
                <h3>16. PROTECCIÓN DE DATOS Y CESIÓN DE DERECHO DE USO DE LA IMAGEN</h3>
                <br />
                <p class="num-p">16.1.</p>
                <p>
                    De conformidad con la Ley Nº 18.331, de 11 de agosto de 2008, de
                    Protección de Datos Personales y Acción de Habeas Data (LPDP), los datos
                    suministrados a partir de la fecha de aceptación de las presentes Bases
                    y Condiciones, por el Usuario, quedarán incorporados a una Base de
                    Datos, base de datos PLUS la cual será procesada exclusivamente para la
                    siguiente finalidad: informar novedades, noticias y promociones del
                    Programa, realizar análisis y estudios, que podrán estar basados en el
                    perfil de la persona, en la respuesta a sus encuestas, en los hábitos de
                    compra, etc. Los datos de carácter personal serán tratados con el grado
                    de protección adecuado, tomándose las medidas de seguridad necesarias
                    para evitar su alteración, pérdida, tratamiento o acceso no autorizado
                    por parte de terceros que lo puedan utilizar para finalidades distintas
                    para las que han sido solicitados. El organismo responsable de la Base
                    de Datos es Suizo., y la dirección donde el titular podrá ejercer los
                    derechos de acceso, rectificación, actualización, inclusión o supresión
                    es en la calle José de Béjar 2600, y/o a través del siguiente mail:
                    consultas.datos@suizo.com.uy (art. 14 y 15 de la Ley Nº 18.331).5.1. El
                    Usuario podrá poner fin a su participación en el Programa en cualquier
                    momento completando la solicitud de baja del servicio, en adelante
                    “Solicitud de Baja” en cualquier unidad de negocio de la Empresa. Una
                    vez el Usuario sea dado de baja no podrá disponer del saldo de Puntos
                    Canjeables que tuviere acumulado, quedando este en 0 (cero).
                </p>
                <br />
                <br />
            </div>
        </section>
        <?php require 'assets/scripts/footer.php'; ?>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>

</html>