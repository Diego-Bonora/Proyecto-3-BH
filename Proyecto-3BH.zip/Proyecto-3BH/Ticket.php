<?php

session_start();
$connect = mysqli_connect("localhost", "root", "proyecto2021", "NetClip");
require 'assets/scripts/database.php';
require './assets/scripts/carritocontent.php';


if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT ID_usuarios, Email, Password, Nombre, Apellido FROM usuarios WHERE ID_usuarios = :ID_usuarios');
    $records->bindParam(':ID_usuarios', $_SESSION['user_id']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
        $user = $results;
    }
}




?>
<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8" />
    <meta http - equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/style/style.css?v=<?php echo time(); ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/68768a5d73.js" crossorigin="anonymous"></script>
    <title>Suizo</title>

    <script>
        $(document).ready(function() {

            $("#hover-cont").mouseover(function() {
                $("#busca-input").removeClass("busca-noshow").addClass("busca-show");
            });

            $("#hover-cont").mouseout(function() {
                $("#busca-input").removeClass("busca-show").addClass("busca-noshow");
            });

            $("#hover-cont").focusin(function() {
                $("#busca-input").removeClass("busca-noshow").addClass("busca-show");
            });

            $("#hover-cont").focusout(function() {
                $("#busca-input").removeClass("busca-show").addClass("busca-noshow");
            });

        });
    </script>
</head>

<body>
    <section id="tabla-fondo-ticket"></section>
    <div class="acomodar">
        <div class="ticket">
            <div class="top-ticket">
                <div class="left-ticket">
                    <p>Suizo Marcket</p>
                    <p>Gabriel Alzamendi</p>
                    <p>Calle Avenida Italia</p>
                    <p>Carrasco Montevideo</p>
                    <p>tel: 099854456</p>
                    <table class="table-ticket-left">
                        <tbody>
                            <tr>
                                <th>consumidor final</th>
                            </tr>
                            <tr>
                                <td>
                                    <img class="img-null" src="./assets/media/buttons/cruz.png">
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="right-ticket">
                    <p>Rut:110265746974</p>
                    <p>E-Ticket de credito</p>
                    <p>SerieA N°<?php
                                $sql = 'SELECT count(*)c FROM tickets';
                                $records = $conn->prepare($sql);
                                $records->execute();
                                $results = $records->fetch(PDO::FETCH_ASSOC);
                                if ($results > 0) {
                                    echo $results['c'] + 1;
                                } else {
                                    echo '1';
                                }
                                ?></p>

                    <?php
                    $day = date("j");
                    $month = date("n");
                    $year = date("Y");
                    ?>
                    <table class="table-ticket-right">
                        <tbody>
                            <tr>
                                <th width="1px"></th>
                                <th width="50%">Fecha</th>
                                <th width="1px"></th>
                            </tr>
                            <tr>
                                <td width=20%><?php print_r($day); ?></td>
                                <td width=20%><?php print_r($month); ?></td>
                                <td width=20%><?php print_r($year); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="flex-center">
                <p>Nombre :</p>
                <p> <?php echo $user['Nombre'], " ", $user['Apellido'] ?></p>
            </div>
            <div class="flex-center">
                <p>Direccion :</p>
                <p>
                    <?php
                    $sql = "SELECT * FROM direccion, usuarios WHERE direccion.ID_direccion = usuarios.Direccion AND usuarios.ID_usuarios = :ID_usuarios";
                    $records = $conn->prepare($sql);
                    $records->bindParam(':ID_usuarios', $_SESSION['user_id']);
                    $records->execute();
                    $results = $records->fetch(PDO::FETCH_ASSOC);
                    if ($results != null) {
                        if (count($results) > 0) {
                            $direccion = $results;
                            echo $direccion['departamento'], " ", $direccion['calle'], " ", $direccion['apartamento'];
                        }
                    } else {
                        $direccion = "Local";
                        echo $direccion;
                    }
                    ?>
                </p>
            </div>

            <table class="table table-light table-border table-ticket">
                <tbody>
                    <tr>
                        <th width="20%">Cantidad</th>
                        <th width="40%">producto</th>
                        <th width="20%">precio unitario</th>
                        <th width="20%">precio total</th>
                    </tr>
                    <?php
                    $subtotal = 0;
                    $iva = 0;
                    $total = 0;
                    ?>
                    <?php foreach ($_SESSION['CARRITO'] as $indice => $producto) { ?>
                        <tr>
                            <td width="20%"><?php echo $producto['CANTIDAD'] ?></td>
                            <td width="40%"><?php echo $producto['NOMBRE'] ?></td>
                            <td width="20%">$<?php echo $producto['PRECIO'] ?></td>
                            <td width="20%">$<?php echo number_format($producto['PRECIO'] * $producto['CANTIDAD'], 2)  ?></td>
                        </tr>
                        <?php
                        $subtotal = $subtotal + ($producto['PRECIO'] * $producto['CANTIDAD']);
                        $iva = $subtotal * 0.22;
                        $totalsi = $subtotal + $iva;
                        $total = ceil($totalsi);
                        ?>
                    <?php } ?>
                </tbody>
            </table>
            <div class="bottom-ticket">
                <div class="bottom-left">
                    <p>I.V.A al dia</p>
                    <p>C.A.E: 8737</p>
                    <p>E-Ticket de credito</p>
                    <p>de 001 a 1000</p>
                    <p>Vencimiento 4/10/2023</p>
                </div>
                <div class="extencion-tabla">
                    <div class="flex">
                        <p>Subtotal</p>
                        <h3>$<?php echo ceil($subtotal); ?></h3>
                    </div>
                    <div class="flex">
                        <p>I.V.A</p>
                        <h3>$<?php echo ceil($iva); ?></h3>
                    </div>
                    <div class="flex">
                        <P>Total</P>
                        <h3>$<?php echo ceil($total); ?></h3>
                    </div>
                </div>
            </div>
            <?php
            $confirm = 0;
            if (!empty($_POST['cerrar'])) {

                $sql = 'INSERT INTO tickets (ID_usuario, ID_direccion, precioF) VALUES (:ID_usuario, :ID_direccion, :precioF)';
                $stmt = $conn->prepare($sql);
                $stmt->bindParam(':ID_usuario', $_SESSION['user_id']);
                $sql = "SELECT * FROM direccion, usuarios WHERE direccion.ID_direccion = usuarios.Direccion AND usuarios.ID_usuarios = :ID_usuarios";
                $records = $conn->prepare($sql);
                $records->bindParam(':ID_usuarios', $_SESSION['user_id']);
                $records->execute();
                $results = $records->fetch(PDO::FETCH_ASSOC);
                if ($results != null) {
                    if (count($results) > 0) {
                        $direccion = $results;
                        $stmt->bindParam(':ID_direccion', $direccion['ID_direccion']);
                    }
                } else {
                    $null = null;
                    $stmt->bindParam(':ID_direccion', $null);
                }
                $stmt->bindParam(':precioF', $total);
                if ($stmt->execute()) {
                    $recordst = $conn->prepare('SELECT * FROM tickets WHERE ID_usuario = :ID_usuario AND precioF = :precioF');
                    $recordst->bindParam(':ID_usuario', $_SESSION['user_id']);
                    $recordst->bindParam(':precioF', $total);
                    $recordst->execute();
                    $resultst = $recordst->fetch(PDO::FETCH_ASSOC);
                    if ($resultst != null) {
                        if (count($resultst) > 0) {
                            $ticketContent = $resultst;
                        }
                    }
                    $sql = 'INSERT INTO fechas (day, month, year, ID_ticket) VALUES (:day, :month, :year, :ID_ticket)';
                    $stmt = $conn->prepare($sql);
                    $stmt->bindParam(':day', $day);
                    $stmt->bindParam(':month', $month);
                    $stmt->bindParam(':year', $year);
                    $stmt->bindParam(':ID_ticket', $ticketContent['ID_tickets']);
                    $stmt->execute();
                    $sql = "SELECT * FROM fechas WHERE ID_ticket = :ID_ticket";
                    $records = $conn->prepare($sql);
                    $records->bindParam(':ID_ticket', $ticketContent['ID_tickets']);
                    $records->execute();
                    $results = $records->fetch(PDO::FETCH_ASSOC);
                    if ($results != null) {
                        if (count($results) > 0) {
                            $fechacontent = $results;
                            $sql = "UPDATE tickets SET fecha = " . $fechacontent['ID_fecha'] . " WHERE ID_tickets = " . $ticketContent['ID_tickets'] . "";
                            $stmt = $conn->prepare($sql);
                            $stmt->execute();
                            echo $fechacontent['ID_fecha'];
                        }
                    }
                    foreach ($_SESSION['CARRITO'] as $indice => $producto) {
                        $sql = 'INSERT INTO compras (ID_producto, cantidad, precioP, ID_ticket) VALUES (:ID_producto, :cantidad, :precioP, :ID_ticket)';
                        $records = $conn->prepare($sql);
                        $records->bindParam(':ID_producto', $producto['ID']);
                        $records->bindParam(':cantidad', $producto['CANTIDAD']);
                        $records->bindParam(':precioP', $producto['PRECIO']);
                        $records->bindParam(':ID_ticket', $ticketContent['ID_tickets']);
                        $records->execute();
                        $confirm = $confirm + 1;
                    }

                    $records = $conn->prepare('SELECT * FROM suscripciones WHERE ID_usuario = :ID_usuario');
                    $records->bindParam(':ID_usuario', $_SESSION['user_id']);
                    $records->execute();
                    $results = $records->fetch(PDO::FETCH_ASSOC);
                    if ($results != null) {
                        if (count($results) > 0) {
                            $puntos = $results;
                        }
                    }

                    $puntossuscripto = $total * 0.20;
                    $puntossuscripto = $puntossuscripto + $puntos['puntos'];
                    $sql = "UPDATE suscripciones SET puntos = " . $puntossuscripto . " WHERE ID_usuario = " . $_SESSION['user_id'] . "";
                    $stmt = $conn->prepare($sql);
                    $stmt->execute();


                    foreach ($_SESSION['CARRITO'] as $indice => $producto) {
                        $records = $conn->prepare('SELECT * FROM catalogo WHERE ID_productos = :ID_productos');
                        $records->bindParam(':ID_productos', $producto['ID']);
                        $records->execute();
                        $results = $records->fetch(PDO::FETCH_ASSOC);
                        if ($results != null) {
                            if (count($results) > 0) {
                                $cantproducto = $results;
                                $newcantidad = $cantproducto['stock'] - $producto['CANTIDAD'];
                                $sql = "UPDATE catalogo SET stock = " . $newcantidad . " WHERE ID_productos = " . $producto['ID'] . "";
                                $stmt = $conn->prepare($sql);
                                $stmt->execute();
                            }
                        }
                    }
                    $newcantidad = $cantproducto['stock'] - $producto['CANTIDAD'];

                    if ($confirm == count($_SESSION['CARRITO'])) {
                        unset($_SESSION['CARRITO']);
                        unset($_SESSION['TICKET']);
                        echo '<script language="javascript">';
                        echo 'window.location.replace("/proyecto-3BH/carrito.php")';
                        echo '</script>';
                    }
                }
            }
            ?>
            <div class="close-ticket">
                <form action="" method="post">
                    <input type="checkbox" name="cerrar" checked hidden />
                    <input class="button-ticket" type="submit" value="cerrar">
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>

</html>