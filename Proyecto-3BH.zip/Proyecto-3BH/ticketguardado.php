<?php

session_start();
$connect = mysqli_connect("localhost", "root", "proyecto2021", "NetClip");
require 'assets/scripts/database.php';
require './assets/scripts/carritocontent.php';


if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT ID_usuarios, Email, Password, Nombre, Apellido FROM usuarios WHERE ID_usuarios = :ID_usuarios');
    $records->bindParam(':ID_usuarios', $_SESSION['user_id']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
        $user = $results;
    }
}

if (!empty($_POST['cerrar'])) {
    echo '<script language="javascript">';
    echo 'window.location.replace("/proyecto-3BH")';
    echo '</script>';
}


if (isset($_GET["page"])) {
    $page = $_GET["page"];
} else {
    $page = 1;
}
$num_per_page = 1;
$start_from = ($page - 1) * 1;

$sql = "SELECT * FROM tickets WHERE ID_usuario = " . $_SESSION['user_id'] . "";
$rs_result = mysqli_query($connect, $sql);
$total_records = mysqli_num_rows($rs_result);
$total_pages = ($total_records / $num_per_page);


?>
<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8" />
    <meta http - equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/style/style.css?v=<?php echo time(); ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/68768a5d73.js" crossorigin="anonymous"></script>
    <title>Suizo</title>

    <script>
        $(document).ready(function() {

            $("#hover-cont").mouseover(function() {
                $("#busca-input").removeClass("busca-noshow").addClass("busca-show");
            });

            $("#hover-cont").mouseout(function() {
                $("#busca-input").removeClass("busca-show").addClass("busca-noshow");
            });

            $("#hover-cont").focusin(function() {
                $("#busca-input").removeClass("busca-noshow").addClass("busca-show");
            });

            $("#hover-cont").focusout(function() {
                $("#busca-input").removeClass("busca-show").addClass("busca-noshow");
            });

        });
    </script>
</head>

<body>
    <div class="acomodar">
        <?php
        $i = 1;
        $query = "SELECT * FROM tickets WHERE ID_usuario = " . $_SESSION['user_id'] . "";
        $result = mysqli_query($connect, $query);
        if (mysqli_num_rows($result) > 0) {
            while ($ticketr = mysqli_fetch_array($result)) {
                

                // $fechaarray = array(
                //     'DAY' => $fecha['day'],
                //     'MONTH' => $fecha['month'],
                //     'YEAR' => $fecha['year'],
                // );
                // $_SESSION['FECHA'][$arraynumber] = $fechaarray;
                // $arraynumber = $arraynumber + 1;
                // $fechaday[$arraynumber] = $fecha['day'];
                // $fechamonth[$arraynumber] = $fecha['month'];
                // $fechayear[$arraynumber] = $fecha['year'];
                // echo $fechaday[$arraynumber];
                // echo $fechamonth[$arraynumber];
                // echo $fechayear[$arraynumber];
                // $arraynumber = $arraynumber + 1;
                // echo $fechaarray['DAY'];
            }
        }
        $query = "SELECT * FROM fechas,tickets WHERE fechas.ID_fecha = tickets.fecha AND tickets.ID_usuario = " . $_SESSION['user_id'] . "";
                $result = mysqli_query($connect, $query);
                if (mysqli_num_rows($result) > 0) {
                    echo "<div class='paginacion-ticket'>";
                    while ($fecha = mysqli_fetch_array($result)) {
                        echo "<div class='paginacion-ticket-num'><a href='ticketguardado.php?page=" . $i . "'>"  . $fecha['day'] . "/"  . $fecha['month'] . "/"  . $fecha['year'] . "</a></div>";
                        $i++;
                    }
                    echo "</div>";
                }
        // $pedro = 0;
        // echo "<div class='paginacion-ticket'>";
        // for ($i = 1; $i <= $total_pages; $i++) {
        //     echo "<div class='paginacion-ticket-num'><a href='ticketguardado.php?page=" . $i . "'>"  . $fechaday[$pedro] . "/"  . $fechamonth[$pedro] . "/"  . $fechayear[$pedro] . "</a></div>";
        //     echo $i;
        //     echo $pedro;
        //     echo $arraynumber;
        //     $arraynumber = $arraynumber + 1;

        // }

        // echo "</div>";

        $query = "SELECT * FROM tickets WHERE ID_usuario = " . $_SESSION['user_id'] . " limit $start_from,$num_per_page";
        $result = mysqli_query($connect, $query);
        if (mysqli_num_rows($result) > 0) {
            while ($ticketr = mysqli_fetch_array($result)) {
        ?>
                <div class="ticket">
                    <div class="top-ticket">
                        <div class="left-ticket">
                            <p>Suizo Marcket</p>
                            <p>Gabriel Alzamendi</p>
                            <p>Calle Avenida Italia</p>
                            <p>Carrasco Montevideo</p>
                            <p>tel: 099854456</p>
                            <table class="table-ticket-left">
                                <tbody>
                                    <tr>
                                        <th>consumidor final</th>
                                    </tr>
                                    <tr>
                                        <td>
                                            <img class="img-null" src="./assets/media/buttons/cruz.png">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="right-ticket">
                            <p>Rut:110265746974</p>
                            <p>E-Ticket de credito</p>
                            <p>SerieA N°<?php echo $ticketr['ID_tickets']; ?></p>
                            <table class="table-ticket-right">
                                <tbody>
                                    <tr>
                                        <th width="1px"></th>
                                        <th width="50%">Fecha</th>
                                        <th width="1px"></th>
                                    </tr>
                                    <tr>
                                        <?php
                                        $query = "SELECT * FROM fechas, tickets WHERE fechas.ID_ticket = tickets.ID_tickets AND tickets.ID_tickets = " . $ticketr['ID_tickets'] . "";
                                        $result = mysqli_query($connect, $query);
                                        if (mysqli_num_rows($result) > 0) {
                                            while ($fechaarray = mysqli_fetch_array($result)) {
                                        ?>
                                                <td width=20%><?php echo $fechaarray['day']; ?></td>
                                                <td width=20%><?php echo $fechaarray['month']; ?></td>
                                                <td width=20%><?php echo $fechaarray['year']; ?></td>
                                        <?php }
                                        } ?>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="flex-center">
                        <p>Nombre :</p>
                        <p> <?php echo $user['Nombre'], " ", $user['Apellido'] ?></p>
                    </div>
                    <div class="flex-center">
                        <p>Direccion :</p>
                        <p>
                            <?php
                            $sql = "SELECT * FROM direccion, tickets WHERE direccion.ID_direccion = tickets.ID_direccion AND tickets.ID_tickets = :ID_ticket";
                            $records = $conn->prepare($sql);
                            $records->bindParam(':ID_ticket', $ticketr['ID_tickets']);
                            $records->execute();
                            $results = $records->fetch(PDO::FETCH_ASSOC);
                            if ($results != null) {
                                if (count($results) > 0) {
                                    $direccion = $results;
                                    echo $direccion['departamento'], " ", $direccion['calle'], " ", $direccion['apartamento'];
                                }
                            } else {
                                $direccion = "Local";
                                echo $direccion;
                            }
                            ?>
                        </p>
                    </div>

                    <table class="table table-light table-border table-ticket">
                        <tbody>
                            <tr>
                                <th width="20%">Cantidad</th>
                                <th width="40%">producto</th>
                                <th width="20%">precio unitario</th>
                                <th width="20%">precio total</th>
                            </tr>
                            <?php
                            $subtotal = 0;
                            $iva = 0;
                            $total = 0;
                            ?>
                            <?php
                            $query = "SELECT * FROM catalogo, compras WHERE catalogo.ID_productos = compras.ID_producto AND compras.ID_ticket = " . $ticketr['ID_tickets'] . "";
                            $result = mysqli_query($connect, $query);
                            if (mysqli_num_rows($result) > 0) {
                                while ($comprasR = mysqli_fetch_array($result)) {
                            ?>
                                    <tr>
                                        <td width="20%"><?php echo $comprasR['cantidad'] ?></td>
                                        <td width="40%"><?php echo $comprasR['Nombre'] ?></td>
                                        <td width="20%">$<?php echo $comprasR['precioP'] ?></td>
                                        <td width="20%">$<?php echo $comprasR['precioP'] * $comprasR['cantidad'] ?></td>
                                    </tr>
                            <?php
                                    $subtotal = $subtotal + $comprasR['precioP'] * $comprasR['cantidad'];
                                    $iva = $subtotal * 0.22;
                                    $totalsi = $subtotal + $iva;
                                    $total = ceil($totalsi);
                                }
                            }


                            ?>
                        </tbody>
                    </table>
                    <div class="bottom-ticket">
                        <div class="bottom-left">
                            <p>I.V.A al dia</p>
                            <p>C.A.E: 8737</p>
                            <p>E-Ticket de credito</p>
                            <p>de 001 a 1000</p>
                            <p>Vencimiento 4/10/2023</p>
                        </div>
                        <div class="extencion-tabla">
                            <div class="flex">
                                <p>Subtotal</p>
                                <h3>$<?php echo ceil($subtotal); ?></h3>
                            </div>
                            <div class="flex">
                                <p>I.V.A</p>
                                <h3>$<?php echo ceil($iva); ?></h3>
                            </div>
                            <div class="flex">
                                <P>Total</P>
                                <h3>$<?php echo ceil($total); ?></h3>
                            </div>
                        </div>
                    </div>
                    <div class="close-ticket">
                        <form action="" method="post">
                            <input type="checkbox" name="cerrar" checked hidden />
                            <input class="button-ticket" type="submit" value="cerrar">
                        </form>
                    </div>
                </div>


            <?php

            }
        } else {
            ?>
            <p>no hay tickets</p>
            <div class="close-ticket">
                <form action="" method="post">
                    <input type="checkbox" name="cerrar" checked hidden />
                    <input class="button-ticket" type="submit" value="cerrar">
                </form>
            </div>
        <?php
        }
        ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>

</html>